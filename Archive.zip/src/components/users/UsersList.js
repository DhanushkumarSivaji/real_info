import React from 'react'

const UserList = ({ contacts, DetailPage }) => (
	<div>
		<section id='posts'>
			<div className='container'>
				<div className='row'>
					<div className='col-md-12'>
						<table className='table  table-bordered'>
							<thead className='thead-dark'>
								<tr>
									<th>Name</th>
									<th>Email</th>
									<th>Phone</th>
									<th>Prof.Type</th>
									<th></th>
								</tr>
							</thead>
							<tbody>
								{contacts &&
									contacts.map((data, index) => (
										<tr key={index}>
											<td>{data.name}</td>
											<td>{data.email}</td>
											<td>{data.phone}</td>
											<td>{data.type}</td>
											<td>
												<button
													onClick={e => DetailPage(data)}
													className='btn btn-secondary'
												>
													<i className='fas fa-angle-double-right'></i> Details
												</button>
											</td>
										</tr>
									))}
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</section>
	</div>
)

export default UserList
